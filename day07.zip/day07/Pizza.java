package day07;
//Circle
class Circle{
	public int radius;
	public String name;
	
	public Circle() {
		this(10,"고구마피자");
	}
	// 인자(매개변수2개) 생성자...
	public Circle(int radius, String name) {
		this.radius = radius;
		this.name = name;
	}
	
	public Circle(int radius) {
		this(radius,"불고기피자");
	}
	public double getArea() {
		return 3.14*radius*radius;
	}
}

public class Pizza {

	public static void main(String[] args) {
		Circle Pizza,Pizza2;
		Pizza = new Circle();
		Pizza2 = new Circle(10, "치즈피자");
		//Pizza.radius = 10;
		//Pizza.name = "자바피자";
		double area = Pizza.getArea();
		System.out.println(Pizza.name + "의 면적은 " + area);
		System.out.println(Pizza2.name + "의 면적은 " + area);
		
		Circle donut = new Circle(); 
		donut.radius = 2; 
		donut.name = "자바도넛"; 
		area = donut.getArea(); 
		System.out.println(donut.name + "의 면적은 " + area);
	}

}
