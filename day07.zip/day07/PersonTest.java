package day07;

public class PersonTest {

	public static void main(String[] args) {
		// person 객체 생성하기
		Person hong = new Person(); // 디폴트 생성자
		// hong.name = "홍길동";
		// hong.age = 20;
		// hong.abc = 'A';
		hong.밥먹기();
		hong.운동하기("헬스");
		
		// hong.addr = "대전 동구 용운동";
		
		System.out.println(hong.getname()); //static 매소드 호출은 클래스 이름으로 사용 가능
		
		Person heo = new Person();
		heo.name = "허령";
		heo.age = 22;
		heo.abc = 'B';
		heo.밥먹기();
		heo.운동하기("테니스");
	}

}
