package day07;

public class Person {
	// 변수
	public static String name;
	public int age;
	public char abc;
	
	private String addr;
	
	// 기본 생성자의 정의: 클래스 이름과 동일한 매소드. 객체 생성 시 호출
	// 역할: 필드(변수초기화)
	public Person() {
		name = "홍길동";
		age = 20;
		abc = 'A';
		System.out.println("객체가 생성됨.");
	}
	public static String getname() {
		return name;
	}
	
	 // 메소드
	public void 밥먹기() {
		System.out.println("밥먹다.");
	 }
	public void 운동하기(String s) {
		System.out.println(s + " 종목을 운동합니다.");
	}
	
	
	public static void main(String[] args) {
		
		

	}

}
