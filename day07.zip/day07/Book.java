package day07;

public class Book {
	String title;
	String author;
	
	public Book (String t) {
		title = t;
		author = "작자미상";
	}

	public Book(String t, String s) {
		title = t;
		author = s;
	}
	public static void main(String[] args) {
		Book littlePrince = new Book("어린왕자", "생텍쥐베리");
		Book lovestory = new Book("춘향전");
		
		System.out.println(littlePrince.title + " " + littlePrince.author);
		System.out.println(lovestory.title + " " + lovestory.author);

	}

}
