package day09;

public class Human extends Animal { //상속 
	private String addr;
public Human() {
	
}
public Human(String name, int age) {
	super(name, age);
}
// public String GetName() { Animal이 가지고 있음
	// return name;
public String getAddr() {
	return this.addr;
}
// public int GetAge() {
	// return age;
public void setAddr(String addr) {
	this.addr = addr;
}
//public void eat() {}
//public void sleep() {}
//public void love() {}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
