package day09;

import java.util.Scanner;
public class Grade {
	// 속성
    String name;
    int abc;
    int def;
    int ghi;
    
    // 인자 생성자
    public Grade(String name, int abc, int def, int ghi) {
        this.name = name;
        this.abc = abc;
        this.def = def;
        this.ghi = ghi;
    }
    
    // 메소드
    public String getName() {
        return name;
    }
    
    //평균을 계산하고 정수로 반환
    public int getAverage() {
        return (abc + def + ghi / 3);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("이름, 자바, 웹프로그래밍, 운영체제 순으로 점수 입력>>");
        String name = scanner.next();
        int adc = scanner.nextInt();
        int def = scanner.nextInt();
        int ghi = scanner.nextInt();

        Grade st = new Grade(name, adc, def, ghi);

        System.out.print(st.getName() + "의 평균은 " + st.getAverage());

        scanner.close();
    }
}