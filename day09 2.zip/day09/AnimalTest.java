package day09;

public class AnimalTest {

	public static void main(String[] args) {
		Animal cat = new Animal();
	    Human hong = new Human();
	    Student kim = new Student("김철수", 18, "2024001");
	    
		// Cat.name = "뽀삐"; <-- 직접 접근이 안됨
		cat.setName("뽀삐");
		hong.setName("홍길동");
		// Cat.age = 10;
		cat.setAge(10);
		hong.setAge(20);
		
		hong.setAddr("대전 중구 용운동");
		kim.
		
	
		System.out.println(cat.getAge());
		System.out.println(cat.getName());
		System.out.println(hong.getName());
		System.out.println(hong.getAddr());
		System.out.println(kim.getSid());
		
		
		
	}

}
