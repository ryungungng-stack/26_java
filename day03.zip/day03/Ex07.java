package day03;

import java.util.Scanner;
public class Ex07 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("점수를 입력하세요: ");
		int num = sc.nextInt();
		String grade;
	
		
		//  점수에 따른 조건
		if(num >= 90) // 90 이상
			grade = "A";
		else if(num >= 80) // 80 이상 90 미만
			grade = "B";
		else if(num >= 70) // 70 이상 80 미만
			grade = "C";
		else if(num >= 60) // 60 이상 70 미만
			grade = "D";
		else // 60 이만
			grade = "F";
			
		System.out.println("학점은 "+ grade + "입니다.");

	}

}
