package day03;

import java.util.Scanner;
public class Ex05 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("점수를 입력하세요: ");
		
		int num = sc.nextInt();
		
		// 70이상이면 합격. 아니면 불합격. 
		if(num >= 70) {
			System.out.println("합격입니다.");
		}
		else {
			System.out.println("불합격입니다.");
		}

	}

}
