package day03;

// import
import java.util.Scanner;
public class Ex01 {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		
		// 변수선언
		int age ; 
		String name = new String();
		double height;
		double weight;
		String city = new String();
		
		// 변수 초기화
		age = 22;
		name = "허령";
		
		// 출력
		//System.out.println("나이: "+ age);
		//System.out.println("이름: "+ name);
		
		// Scanner 객체 생성 
		Scanner scan = new Scanner(System.in);
		System.out.println("나이를 입력하세요: ");
		age = scan.nextInt();
		System.out.println("이름을 입력하세요: ");
	    name = scan.next();
	    System.out.println("키를 입력하세요: ");
	    height = scan.nextDouble();
	    System.out.println("몸무게를 입력하세요: ");
	    weight = scan.nextDouble();
	    System.out.println("도시를 입력하세요: ");
	    city = scan.next();
	    
	    
	    System.out.println("나이: "+ age);
		System.out.println("이름: "+ name);
		System.out.println("키: "+ height);
		System.out.println("몸무게: "+weight);
		System.out.println("도시: "+ city);
	} 

}