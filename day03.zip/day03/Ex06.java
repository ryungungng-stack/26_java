package day03;

import java.util.Scanner;
public class Ex06 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		String id = "hong", pwd = "1234";
		
		System.out.println("아이디를 입력하세요: ");
		String myid = sc.next();
		
		System.out.println("비밀번호를 입력하세요: ");
		String mypwd = sc.next();
	
		
		// 아이디 비번이 같으면 로그인, 아니면 실패 
		if(id.equals(myid) && pwd.equals(mypwd)) {
	
			System.out.println("로그인 성공!");
		}
		else {
			System.out.println("로그인 실패!");
		}

	}

}
