package day03;

import java.util.Scanner;
public class Ex04 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("정수를 입력하세요: ");
		
		int num = sc.nextInt();
		
		// 짝수면 짝수. 홀수면 홀수. 
		if(num % 2 == 0) {
			System.out.println("짝수입니다.");
		}
		else {
			System.out.println("홀수입니다.");
		}

	}

}
