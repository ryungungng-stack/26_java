package day03;

import java.util.Scanner;
public class Ex02 {

	public static void main(String[] args) {
		
		// 입력
		Scanner scan = new Scanner(System.in);
		System.out.print("정수를 입력하세요: ");
		
		// 변수 선언
		int time = scan.nextInt(); // 정수 입력
		int second = time % 60; // 60으로 나눈 나머지는 초
		int minute = (time / 60) % 60; // 60으로 나눈 몫을 다시 60으로 나눈 나머지는 분
		int hour = (time / 60) / 60; // 60으로 나눈 몫을 다시 60으로 나눈 몫은 시간
		
		// 출력	
		System.out.println(time + "초는 " + hour + "시간, " + minute + "분, " + second + "초입니다.");
		

	}

}