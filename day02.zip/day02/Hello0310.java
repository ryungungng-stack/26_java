package day02;

public class Hello0310 {

	public static void main(String[] args) {
		// TODO Print 계열 매소드를 이용해 자바로 하고싶은 것 작성해서 출력
		
	System.out.println("저는 자바를 이용해서 저만의 웹페이지를 만들고 싶습니다!");
	System.out.println("저를 표현할 수 있는 페이지가 있다면 좋다고 생각하기 떄문입니다.");

	}

}
