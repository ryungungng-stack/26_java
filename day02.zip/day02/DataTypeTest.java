package day02;

public class DataTypeTest {

	public static void main(String[] args) {
		// 1. 기본형 변수 선언
		boolean isTrue;
		int age;
		double height, weight;
		
		// 2. 변수 초기화
		isTrue = false;
		age = 22;
		height = 189.5;
		weight = 90.4;
		
		// 3. 래퍼런스형 = 3개 (배열, 클래스, 인터페이스)
		String name;
		name = "허령"; // String name = "허령" -> 선언과 초기화를 동시에도 가능
		String s = new String("홍길동");
		String addr = new String("대전시 중구 대흥로 157번길, 5");
		
		DataTypeTest dtt = new DataTypeTest(); //래퍼런스형 클래스 만들
		
		// 4. 변수 값 출력
		System.out.println(isTrue);
		System.out.println("나이: " + age); // + -> 연결 연산자(문자와문자사이에서)
 		System.out.println("몸무게: " + weight);
		System.out.println("키: " + height);
		System.out.println("이름: " + name);
		System.out.println(s);
		System.out.println("주소: " +addr);
		
	
		

	}

}
