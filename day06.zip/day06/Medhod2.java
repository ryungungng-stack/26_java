package day06;

import java.util.Scanner;
public class Medhod2 {

    public static int max(int n1, int n2) {
        if (n1 > n2) {
            return n1;
        } else {
            return n2;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("첫 번째 정수 입력: ");
        int num1 = sc.nextInt();

        System.out.print("두 번째 정수 입력: ");
        int num2 = sc.nextInt();

        int result = max(num1, num2);

        System.out.println("더 큰 값은: " + result);
    }
}