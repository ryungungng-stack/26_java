package day06;

import java.util.Scanner;
public class Medhod1 {
	
	// 1. 매개변수 없고, 반환형도 없는 add()메소드
	public static void add(){
		Scanner sc = new Scanner(System.in);
		System.out.println("정수를 입력하세요: ");
		int num = sc.nextInt();
		int sum = sc.nextInt();
		System.out.println(num+sum);
	}
	
	//2. 매개변수 있고, 반환형은 없는 add()메소드
	public static void add(int a, int b) {
		System.out.println(a+b);
	}
	//3. 매개변수 없고, 반환형은 있는 add()메소드
	public static int add1(){
		Scanner sc = new Scanner(System.in);
		System.out.println("정수를 입력하세요: ");
		int num1 = sc.nextInt();
		int sum1 = sc.nextInt();
		return num1+sum1;
	}
	//4. 매개변수와 반환형 모두 있는 add()메소드
	public static int add2(int a, int b) {
		return a+b;
	}
	public static void main(String[] args) {
		//add();
		//add(50,60);
		// System.out.println(add1());
		int result = add2(50,60);
		System.out.println(result);

	}

}
