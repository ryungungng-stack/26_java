package day06;

public class Overloading {

	public static void coffee (int c) {
		System.out.println("블랙커피 만듭니다");
	}
	public static void coffee (int c, int cr) {
		System.out.println("크림커피 만듭니다");
		
	}
	public static void coffee (int c, int cr, int s) {
		System.out.println("믹스커피 만듭니다");
		
	}
	public static void main(String[] args) {
		coffee(3);
		coffee(3,3);
		coffee(3,3,3);
	}

}
