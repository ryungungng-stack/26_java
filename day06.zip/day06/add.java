package day06;

import java.util.Scanner;
public class add {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("정수를 입력하세요: ");
		
		int num = sc.nextInt();
		System.out.println("정수를 입력하세요: ");
		
		int sum = sc.nextInt();
		
		int add = sum + num;
		
		System.out.println("합: " + add);

	}

}
