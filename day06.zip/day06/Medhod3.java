package day06;

import java.util.Scanner;
public class Medhod3 {
    
    public static int add(int a, int b) {
        return a + b;
    }
        
    public static int sub(int a, int b) {
        return a - b;
    }
    
    public static int mul(int a, int b) {
        return a * b;
    }
    
    public static int div(int a, int b) {
        return a / b;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int a, b;
        String x;
        
        System.out.print("첫 번째 정수를 입력하세요: ");
        a = sc.nextInt();
        System.out.print("두 번째 정수를 입력하세요: ");
        b = sc.nextInt();
        System.out.print("연산 부호를 입력하세요: ");
        x = sc.next();
        
        switch(x) {
            case "+":
                System.out.println("결과: " + add(a, b));
                break;
            case "-":
                System.out.println("결과: " + sub(a, b));
                break;
            case "*":
                System.out.println("결과: " + mul(a, b));
                break;
            case "/":
                System.out.println("결과: " + div(a, b));
                break;
            default:
                break;
        }
        
    }
}