package day04;

import java.util.Scanner;
public class Ex09 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int sum = 0;
		System.out.println("정수를 입력하시오");
		
		for (int i = 1; i<=5; i++) {
			int num = sc.nextInt();
			if(num < 0) {
				continue;
			} else {
				sum = sum + num;
			}
		}
		System.out.println("양수의 합: " + sum);
	}

}
