package day04;

public class gugudan {

	public static void main(String[] args) {
			
		for(int i=1; i<10; i++) {
				for(int l=1; l<10; l++) {
				System.out.print(i + "*" + l + "=" + i*l);
				System.out.print('\t'); 
			}
			System.out.println(); 
		}

	}
}