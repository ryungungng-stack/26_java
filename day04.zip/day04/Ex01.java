package day04;

import java.util.Scanner;
public class Ex01 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("나이를 입력하세요: ");
		int num = sc.nextInt();
		
		if(num <= 18)
			System.out.println("청소년 관람 불가");

	}

}
