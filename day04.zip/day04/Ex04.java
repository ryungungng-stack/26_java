package day04;
import java.util.Scanner;
public class Ex04{

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		
		System.err.println("가위,바위,보 게임입니다.");
		System.err.println("철수>>");
		String user1 = sc.next();
		
		System.err.println("영희>>");
		String user2 = sc.next();
		
		//철수가 이길 경우
		if(user1.equals("보")&&user2.equals("바위")){
			System.err.println("철수 승");
			
		}else if(user1.equals("바위")&&user2.equals("가위")){
			System.err.println("철수 승");

		}else if(user1.equals("가위")&&user2.equals("보")) {
			System.err.println("철수 승");
			
			
		//영희가 이길 경우
		}else if(user2.equals("가위")&&user1.equals("보")) {
			System.err.println("영희 승");

		}else if(user2.equals("바위")&&user1.equals("가위")) {
			System.err.println("영희 승");

		}else if(user2.equals("보")&&user1.equals("바위")) {
			System.err.println("영희 승");
			
		//비길 경우	
		}else if(user2.equals(user1)) {
			System.out.println("비김");
		}

	}
}
