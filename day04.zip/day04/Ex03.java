package day04;

import java.util.Scanner;
public class Ex03 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int balance = 10000;
		System.out.println("나이(만나이)를 입력하세요: ");
		int num = sc.nextInt();
		int sum;
		
		if(num >= 7 && num <= 12){
			sum = balance - 450;
			System.out.println("어린이: " + sum);
		}
			else if (num >= 13 && num <= 18) {
			sum = balance - 720;
			System.out.println("청소년: " + sum);
		}
			else if(num >= 19){
			sum = balance - 1200;
			System.out.println("어른: " + sum);
			}
	}
}
