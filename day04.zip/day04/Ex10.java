package day04;

import java.util.Scanner;
public class Ex10 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int sum = 0;
		System.out.println("정수를 입력하시오");
		
		while(true) {
			int num =sc.nextInt();
			if(num<0) {
				break;
			} else {
				sum = sum + num;
			}ss
		}
		System.out.println("합: " + sum);
	}

}
