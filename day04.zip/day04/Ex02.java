package day04;

import java.util.Scanner;
public class Ex02 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("필기 시험 점수를 입력하세요: ");
		int num = sc.nextInt();
		System.out.println("토익 점수를 입력하세요: ");
		int sum = sc.nextInt();
		
		if(num >= 80 && sum >= 850)
			System.out.println("합격");
		else System.out.println("불합격");

	}

}
