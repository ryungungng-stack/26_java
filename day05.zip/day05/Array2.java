package day05;

public class Array2 {

	public static void main(String[] args) {
	String name[] = {"사과", "배", "바나나", "체리", "딸기", "포도" };
	try {
	for (int i = 0;i<7;i++) {
		System.out.println(name[i]);
	}
		} catch(ArrayIndexOutOfBoundsException ao){
			ao.printStackTrace();
		}
	
	}

}
