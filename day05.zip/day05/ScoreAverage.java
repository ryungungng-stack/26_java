package day05;

public class ScoreAverage {

	public static void main(String[] args) {
		double score[][]= {{3.3, 3.4},
					       {3.5, 3.6}, 
					       {3.7, 4.0}, 
					       {4.1, 4.2} };
		double sum =0;
		
		try {
		for(int year=0;year<4 ;year++) {
			for(int term=0; term<score[year].length;term++) {
				sum += score[year][term];
			}
		}
		}
		catch(ArrayIndexOutOfBoundsException ao){
			ao.printStackTrace();
		}
		int n = score.length;
		int m = score[0].length;
		
		System.out.print("4년 전체 점 평균은 "+ sum/(n*m));
		}

	}

