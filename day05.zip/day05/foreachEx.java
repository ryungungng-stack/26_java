package day05;

public class foreachEx {

	public static void main(String[] args) {
		int num[] = {1,2,3,4,5};
		int sum =0;
		
		for(int n : num)
			sum += n;
		System.out.println(sum);
		
	}
}